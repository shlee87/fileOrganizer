"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { RefreshCw, File, CheckCircle, XCircle, ArrowRight } from "lucide-react"

interface PreviewFile {
  file_path: string
  would_process: boolean
  reason: string
  destination_path?: string
}

interface FilePreviewResponse {
  files: PreviewFile[]
}

export function FilePreviewPage() {
  const [files, setFiles] = useState<PreviewFile[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const fetchFilePreview = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/v1/files/preview")
      if (response.ok) {
        const data: FilePreviewResponse = await response.json()
        setFiles(data.files)
      }
    } catch (error) {
      console.error("Failed to fetch file preview:", error)
      // Mock data for development
      setFiles([
        {
          file_path: "/workplace/contract_delta_2025-01-22_draft.pdf",
          would_process: true,
          reason: "Valid PDF contract file with proper naming convention",
          destination_path: "/dest/delta/contracts/2025/contract_delta_2025-01-22_draft.pdf",
        },
        {
          file_path: "/workplace/temp_file.tmp",
          would_process: false,
          reason: "Temporary file extension not supported",
        },
        {
          file_path: "/workplace/invoice_gamma_inc_2025-01-21.pdf",
          would_process: true,
          reason: "Invoice file detected with valid format",
          destination_path: "/dest/gamma_inc/invoices/2025/invoice_gamma_inc_2025-01-21.pdf",
        },
        {
          file_path: "/workplace/.hidden_file",
          would_process: false,
          reason: "Hidden files are excluded from processing",
        },
        {
          file_path: "/workplace/report_annual_2024.docx",
          would_process: true,
          reason: "Document file with recognizable pattern",
          destination_path: "/dest/reports/annual/2024/report_annual_2024.docx",
        },
        {
          file_path: "/workplace/corrupted_file.pdf",
          would_process: false,
          reason: "File appears to be corrupted or unreadable",
        },
      ])
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    await fetchFilePreview()
  }

  const getProcessBadge = (wouldProcess: boolean) => {
    if (wouldProcess) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100 flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          Will Process
        </Badge>
      )
    } else {
      return (
        <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100 flex items-center gap-1">
          <XCircle className="h-3 w-3" />
          Will Skip
        </Badge>
      )
    }
  }

  const getFileIcon = (filePath: string) => {
    const extension = filePath.split(".").pop()?.toLowerCase()
    return <File className="h-4 w-4 text-muted-foreground" />
  }

  useEffect(() => {
    fetchFilePreview()
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">File Preview</h1>
          <p className="text-muted-foreground mt-2">Preview files in the workplace and see what would be processed</p>
        </div>
        <Button
          onClick={handleRefresh}
          disabled={refreshing}
          variant="outline"
          className="flex items-center gap-2 bg-transparent"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading file preview...</div>
      ) : files.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <File className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No Files Found</h3>
            <p className="text-muted-foreground">No files are currently in the workplace directory</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {files.map((file, index) => (
            <Card key={index} className="transition-shadow hover:shadow-md">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {getFileIcon(file.file_path)}
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base font-mono truncate" title={file.file_path}>
                        {file.file_path}
                      </CardTitle>
                    </div>
                  </div>
                  {getProcessBadge(file.would_process)}
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Reason:</p>
                    <p className="text-sm">{file.reason}</p>
                  </div>

                  {file.would_process && file.destination_path && (
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-sm text-muted-foreground mb-2">Destination Path:</p>
                      <div className="flex items-center gap-2 text-sm font-mono">
                        <span className="text-muted-foreground truncate">{file.file_path}</span>
                        <ArrowRight className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span className="text-foreground truncate" title={file.destination_path}>
                          {file.destination_path}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {files.length > 0 && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Total files: {files.length}</span>
              <div className="flex gap-4">
                <span className="flex items-center gap-1">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  Will process: {files.filter((f) => f.would_process).length}
                </span>
                <span className="flex items-center gap-1">
                  <XCircle className="h-3 w-3 text-red-600" />
                  Will skip: {files.filter((f) => !f.would_process).length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
