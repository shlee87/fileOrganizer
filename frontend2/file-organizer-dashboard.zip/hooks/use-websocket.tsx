"use client"

import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react"

interface WebSocketMessage {
  type: "service.status_changed" | "file.processed"
  data: any
}

interface ServiceStatusChangedData {
  status: "running" | "stopped" | "error"
  uptime_seconds: number
}

interface FileProcessedData {
  original_path: string
  destination_path: string
  status: "processed" | "failed"
  processed_at: string
  file_size_bytes: number
}

interface WebSocketContextType {
  isConnected: boolean
  lastMessage: WebSocketMessage | null
  sendMessage: (message: any) => void
}

const WebSocketContext = createContext<WebSocketContextType | null>(null)

interface WebSocketProviderProps {
  children: ReactNode
}

export function WebSocketProvider({ children }: WebSocketProviderProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null)
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5

  const connect = () => {
    try {
      const ws = new WebSocket("ws://localhost:8080/api/v1/ws")

      ws.onopen = () => {
        console.log("[v0] WebSocket connected")
        setIsConnected(true)
        reconnectAttempts.current = 0
      }

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data)
          console.log("[v0] WebSocket message received:", message)
          setLastMessage(message)
        } catch (error) {
          console.error("[v0] Failed to parse WebSocket message:", error)
        }
      }

      ws.onclose = () => {
        console.log("[v0] WebSocket disconnected")
        setIsConnected(false)
        wsRef.current = null

        // Attempt to reconnect with exponential backoff
        if (reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.pow(2, reconnectAttempts.current) * 1000
          console.log(`[v0] Attempting to reconnect in ${delay}ms...`)

          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++
            connect()
          }, delay)
        }
      }

      ws.onerror = (error) => {
        console.error("[v0] WebSocket error:", error)
      }

      wsRef.current = ws
    } catch (error) {
      console.error("[v0] Failed to create WebSocket connection:", error)
    }
  }

  const sendMessage = (message: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message))
    }
  }

  useEffect(() => {
    connect()

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
      if (wsRef.current) {
        wsRef.current.close()
      }
    }
  }, [])

  return (
    <WebSocketContext.Provider value={{ isConnected, lastMessage, sendMessage }}>{children}</WebSocketContext.Provider>
  )
}

export function useWebSocket() {
  const context = useContext(WebSocketContext)
  if (!context) {
    throw new Error("useWebSocket must be used within a WebSocketProvider")
  }
  return context
}

// Specific hooks for different message types
export function useServiceStatusUpdates() {
  const { lastMessage } = useWebSocket()
  const [statusUpdate, setStatusUpdate] = useState<ServiceStatusChangedData | null>(null)

  useEffect(() => {
    if (lastMessage?.type === "service.status_changed") {
      setStatusUpdate(lastMessage.data as ServiceStatusChangedData)
    }
  }, [lastMessage])

  return statusUpdate
}

export function useFileProcessedUpdates() {
  const { lastMessage } = useWebSocket()
  const [fileUpdate, setFileUpdate] = useState<FileProcessedData | null>(null)

  useEffect(() => {
    if (lastMessage?.type === "file.processed") {
      setFileUpdate(lastMessage.data as FileProcessedData)
    }
  }, [lastMessage])

  return fileUpdate
}
